﻿using ENO_API.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Data.EFCore
{
    public abstract class EfCoreRepository<TEntity, TContext> : IRepository<TEntity>
         where TEntity : class, IEntity
         where TContext : DbContext
    {
        private readonly TContext context;
        public EfCoreRepository(TContext context)
        {
            this.context = context;
        }
        public async Task<TEntity> Add(TEntity entity)
        {
            context.Set<TEntity>().Add(entity);
            await context.SaveChangesAsync();
            return entity;
        }

       

        public async Task<TEntity> Get(int id)
        {
            return await context.Set<TEntity>().FindAsync(id);
        }


        public async Task<List<Customer>> GetAllCustomers()
        {
            return await context.Set<Customer>().Include(c =>c.CustomerRole).Include(a =>a.Company).ToListAsync();
        }

        public async Task<List<TEntity>> GetAll()
        {
            return await context.Set<TEntity>().ToListAsync();
        }

        public async Task<Customer> UpdateStatus(Customer customer)
        {
            context.Update(customer);
            await context.SaveChangesAsync();
            return customer;
        }
        public async Task<Customer> AddCustomer(Customer customer)
        {
            context.Set<Customer>().Add(customer);
            await context.SaveChangesAsync();
            return customer;
        }

        public async Task<Attachments> AddFiles(Attachments file)
        {
            context.Set<Attachments>().Add(file);
            await context.SaveChangesAsync();
            return file;
        }

        public async Task<List<Company>> GetAllCompanies()
        {
            return await context.Set<Company>().ToListAsync();
        }

        public async Task<Settings> AddSettings(Settings settings)
        {
            context.Set<Settings>().Add(settings);
            await context.SaveChangesAsync();
            return settings;
        }
        public async Task<List<Settings>> GetAllSettings()
        {
            return await context.Set<Settings>().Include(c => c.Company).Include(c => c.Customer).ToListAsync();
        }
        public async Task<List<Settings>> GetSettingByFileName(string fileName)
        {
            var settings =  await context.Set<Settings>().Include(c => c.Company).Include(c => c.Customer).ToListAsync();
            if (settings.Count >0)
            {
                return settings.Where(s => s.FileName == fileName).ToList();
            }
            else
            {
                return null;
            }
        }


        public async Task<List<Settings>> GetSettingBySettingName(string fileName)
        {
            var settings = await context.Set<Settings>().Include(c => c.Company).Include(c =>c.Customer).ToListAsync();
            if (settings.Count > 0)
            {
                return settings.Where(s => s.SettingName == fileName).ToList();
            }
            else
            {
                return null;
            }
        }
        public async Task<Settings> UpdateSettingByName(Settings setting)
        {
            context.Update(setting);
            await context.SaveChangesAsync();
            return setting;
        }

    }
}
