﻿// Copyright (c) Microsoft. All rights reserved. Licensed under the MIT license. See full license in the root of the repo.

"use strict";

let dialog;

Office.initialize = function () {
    $(document).ready(function () {
        app.initialize();

        $("#getOneDriveFilesButton").click(getFileNamesFromGraph);
        $("#logoutO365PopupButton").click(logout);        
    });
};

function ClickOnDoc(item) {
 getOneFile(item);
    app.showNotification("loading: " + item);
}



function getLetter(index) {


    switch (index) {
        case 1:
            return "A";
         
        case 2:
            // code block
            return "B";
        case 3:
            // code block
            return "C";
        case 4:
            // code block
            return "D";
        case 5:
            // code block
            return "E";
        case 6:
            // code block
            return "F";
        case 7:
            // code block
            return "G";
        case 8:
            // code block
            return "H";
        case 9:
            return "I";
            // code block
        case 10:
            return "J";
            // code block
            // code block
        case 11:
            // code block
            return "K";
        case 12:
            // code block
            return "L";
        case 13:
            // code block
            return "M";
        case 14:
            // code block
            return "N";
        case 15:
            // code block
            return "O";
        case 16:
        // code block
            return "P";
        case 17:
            // code block
            return "Q";
        case 18:
            return "R";
        // code block
        // code block
        case 19:
            // code block
            return "S";
        case 20:
            // code block
            return "T";
        case 21:
            // code block
            return "U";
        case 22:
            // code block
            return "V";
        case 23:
            // code block
            return "C";
        case 24:
            // code block
            return "W";
        case 25:
            // code block
            return "Z";
        default:
            return "Z";
    }

}

function getOneFile(fineName) {

    $("#instructionsContainer").hide();
    $("#waitContainer").show();

    $.ajax({
        url: "/files/GetOneFile?fileName=" + encodeURIComponent( fineName ),
        type: "GET"
    })
        .done(function (result) {
            writeFileNamesToOfficeDocument(result)
                .then(function () {
                    
                     return Excel.run(function (context) {
                        const sheet = context.workbook.worksheets.getActiveWorksheet();
                         var nameArr = result.split('\n');
                         var outterArray = [];
                         var innerL = 0;
                         var headerLength = 0;
                         var errorItems;
                         var its = [];
                         $.each(nameArr, function () {
                             var line = this;
                            
                               
                             if (line.indexOf(';') > 0){
                                 its = line.split(';');
                             } else if (line.indexOf(',') > 0) {
                                 its = line.split(',');
                             }
                             var l = its.length;
                             if (headerLength === 0) {
                                 headerLength = its.length;
                             }
                         
                             if (l === headerLength) {
                                 innerL = l;
                                 outterArray.push(its);
                             } else {
                                 errorItems = errorItems + "###" + its.toString();
                                 
                             }

                         });
                         
                         const data = [[nameArr[0], nameArr[1], nameArr[2], nameArr[3], nameArr[4], nameArr[5], nameArr[6]]];
                         var address = "A1:" + getLetter(innerL)  + outterArray.length;
                         const range = sheet.getRange(address);
                         range.values = outterArray;
                        range.format.autofitColumns();
                         app.showNotification("Completed.");
                        return context.sync();
                    });
                  
                })
                .catch(function (error) {
                    app.showNotification(error.toString());
                });
        })
        .fail(function (result) {
            app.showNotification("Sorry something went wrong: " + result.toString());
        });
}

function loadFile() {

    var fileName = $("#TitleDetail").text();

    ClickOnDoc(fileName);
}

function selectFile(fileName) {

   $("#TitleDetail").text(fileName);

    $("#filesContainer").hide();
    $("#oneFileContainer").show();
}


function pivotTable(suffix) {
    var fileName = $("#TitleDetail").text();

    fileName = fileName.replace(".csv", "");
    Excel.run(function (ctx) {
        var sheet_name = fileName + "_pivort_" + suffix;

        sheet_name = "pivort_sheet_";

        var res = str.split(".");
        if (res.length > 0) {
            sheet_name = sheet_name + res[0];
        }
        const sheet = ctx.workbook.worksheets.getActiveWorksheet();
        const farmData = sheet.getUsedRange();

        var rangeToAnalyze = farmData;
        ctx.workbook.worksheets.add(sheet_name);
        var rangeToPlacePivot = ctx.workbook.worksheets.getItem(sheet_name).getRange("A1");
        ctx.workbook.worksheets.getItem(sheet_name).pivotTables.add(
            "Sample", rangeToAnalyze, rangeToPlacePivot);
        var pivotTable = ctx.workbook.pivotTables.getItem("Sample");
        //pivotTable.rowHierarchies.add(pivotTable.hierarchies.getItem("UnitPrice"));
        //pivotTable.rowHierarchies.add(pivotTable.hierarchies.getItem("Quantity"));

        //pivotTable.dataHierarchies.add(pivotTable.hierarchies.getItem("CustomerName"));
        //pivotTable.dataHierarchies.add(pivotTable.hierarchies.getItem("ShipCountry"));

        //const sheet2 = ctx.workbook.worksheets.getItem(sheet_name);
        //var slicer = sheet2.slicers.add(
        //    "Sample" /* The slicer data source. For PivotTables, this can be the PivotTable object reference or name. */,
        //    "ShipCountry" /* The field in the data to filter by. For PivotTables, this can be a PivotField object reference or ID. */
        //);
        //slicer.name = "Country Slicer";
        ////var slicer = ctx.workbook.slicers.getItem("ShipCountry");
        //// Anything other than the following three values will be filtered out of the PivotTable for display and aggregation.
        //slicer.selectItems(["Germany", "Mexico"]);
        return ctx.sync();

        // ctx.workbook.worksheets.getActiveWorksheet().pivotTables.add(
        //     "Sample", farmData, "A22");
        //// var rangeToAnalyze = ctx.workbook.worksheets.getItem("DataWorksheet").getRange("A1:E21");
        // var rangeToPlacePivot = ctx.workbook.worksheets.getItem("ID").getRange("A2");
        // ctx.workbook.worksheets.getItem("ID").pivotTables.add(
        //     "Sample", farmData, rangeToPlacePivot);

        // var pivotTable = ctx.workbook.worksheets.getActiveWorksheet().pivotTables.getItem("Sample");
        // pivotTable.rowHierarchies.add(pivotTable.hierarchies.getItem("ID"));
        // pivotTable.rowHierarchies.add(pivotTable.hierarchies.getItem("Name"));
        // ctx.workbook.pivotTables.add(
        //  "Farm Sales", "DataWorksheet!A1:E21", "PivotWorksheet!A2");

        //return ctx.sync();
    });


}


function getFileNamesFromGraph() {
    $("#filesContainer").show();
    $("#oneFileContainer").hide();
    $("#filesContainer").append('<a href="#" onclick="selectFile(\'' + "test 01" + '\')">' + "test item 01" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 02" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 03" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 04" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 01" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 02" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 03" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 04" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 01" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 02" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 03" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 04" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 01" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 02" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 03" + '</a> </br>');
    $("#filesContainer").append('<a href="#" onclick="ClickOnDoc(\'' + "test " + '\')">' + "test item 04" + '</a> </br>');
    $("#instructionsContainer").hide();
    $("#waitContainer").show();

    $.ajax({
        url: "/files/GetFiles",
        type: "GET"
    })
        .done(function (result) {
            $("#filesContainer").innerHTML  = "";
        writeFileNamesToOfficeDocument(result)
            .then(function () {
              var items=  JSON.parse(result);
                $.each(items, function () {
                    $("#filesContainer").append('<a href="#" class="file-item" onclick="selectFile(\'' + this + '\')">' + this + '</a> </br>');
                });
             
                $("#waitContainer").hide();
                $("#finishedContainer").show();
            })
            .catch(function (error) {
                app.showNotification(error.toString());
            });
    })
        .fail(function (result) {
            app.showNotification("Cannot get data from MS Graph: " + result.toString());
    });
}

function writeFileNamesToOfficeDocument(result) {

    return new OfficeExtension.Promise(function (resolve, reject) {
        try {
            switch (Office.context.host) {
                case "Excel":
                    writeFileNamesToWorksheet(result);
                    break;
                case "Word":
                    writeFileNamesToDocument(result);
                    break;
                case "PowerPoint":
                    writeFileNamesToPresentation(result);
                    break;
                default:
                    throw "Unsupported Office host application: This add-in only runs on Excel, PowerPoint, or Word.";
            }
            resolve();
        }
        catch (error) {
            reject(Error("Unable to add filenames to document. " + error.toString()));
        }
    });    
}

function writeFileNamesToWorksheet(result) {
    
     return Excel.run(function (context) {
        const sheet = context.workbook.worksheets.getActiveWorksheet();

        const data = [
             [result[0]],
             [result[1]],
             [result[2]]];

        const range = sheet.getRange("B5:B7");
        range.values = data;
        range.format.autofitColumns();

        return context.sync();
    });
}

function writeFileNamesToDocument(result) {

     return Word.run(function (context) {

        const documentBody = context.document.body;
        for (let i = 0; i < result.length; i++) {
            documentBody.insertParagraph(result[i], "End");
        }

        return context.sync();
    });
}

function writeFileNamesToPresentation(result) {

    const fileNames = result[0] + '\n' + result[1] + '\n' + result[2];

    Office.context.document.setSelectedDataAsync(
        fileNames,
        function (asyncResult) {
            if (asyncResult.status === Office.AsyncResultStatus.Failed) {
                throw asyncResult.error.message;
            }
        }
    );
}

function logout() {

    var url = "/azureadauth/Logout";
    logOutUser(url);
}
function logOutUser(url) {

    $.ajax({
        url: url,
        type: "GET"
    })
        .done(function (result) {
            document.location.href = "/home/index";
        })
        .fail(function (result) {
            app.showNotification("Cannot get data from MS Graph: " + result.toString());
        });
}
function processLogoutMessage(messageFromLogoutDialog) {

    
}