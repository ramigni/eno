﻿
using Owin;


namespace ENOASPNET
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
           
        }
    }
}