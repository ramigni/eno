import React, { createContext, useContext, useState } from "react";

const UserContex = createContext();

export const useUsers = () => {
  return useContext(UserContex);
};

const UserProvider = ({ children }) => {
  const [user, setUser] = useState({});

  return (
    <UserContex.Provider value={{ user, setUser }}>
      {children}
    </UserContex.Provider>
  );
};

export const UserContexEl = UserProvider;
