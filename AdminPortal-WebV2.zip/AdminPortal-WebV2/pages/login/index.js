import SignInSide from "./../../src/account/Login";
export default SignInSide;
