import { Box, Grid } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import React from "react";

import SideMenu from "./SideMenu";

const useStyles = makeStyles({
  root: {
    width: 230,
  },
});

export default function MyAccount({ children }) {
  const classes = useStyles();

  return (
    <Grid component={Box} pt={2} pb={2} spacing={1} container>
      <Grid item xs={12} md={3} sm={12}>
        <SideMenu />
      </Grid>

      <Grid component={Box} item xs={12} md={9} sm={12}>
        <Box pt={1}>{children}</Box>
      </Grid>

      {/* <Grid component={Box} item xs={12}>
        <Box mb={2}>
          <WishListCarousel />
        </Box>
      </Grid> */}
    </Grid>
  );
}
