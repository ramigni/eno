import React, { useState, useEffect } from "react";
import Avatar from "@material-ui/core/Avatar";
import Button from "@material-ui/core/Button";

import TextField from "@material-ui/core/TextField";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Link from "@material-ui/core/Link";
import Paper from "@material-ui/core/Paper";
import Box from "@material-ui/core/Box";
import Grid from "@material-ui/core/Grid";
import LockOutlinedIcon from "@material-ui/icons/LockOutlined";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import { Divider } from "@material-ui/core";
import { Formik } from "formik";
import { UserRegister, GetCompanies } from "../service/AccountService";
import axios from "axios";
import Alert from "@material-ui/lab/Alert";
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import CustomSelect from "./../components/CustomSelect";
import CircularProgress from "@material-ui/core/CircularProgress";
// function Copyright() {
//   return (
//     <Typography variant="body2" color="textSecondary" align="center">
//       {"Copyright © "}
//       <Link color="inherit" href="https://material-ui.com/">
//         Your Website
//       </Link>{" "}
//       {new Date().getFullYear()}
//       {"."}
//     </Typography>
//   );
// }

const useStyles = makeStyles((theme) => ({
  root: {
    // height: "100vh",
  },
  image: {
    backgroundImage: "url(/assets/images/ENO_Logo.png)",
    backgroundRepeat: "no-repeat",

    backgroundPosition: "center",
  },
  paper: {
    //margin: theme.spacing(8, 4),
    //  display: "flex",
    //  flexDirection: "column",
    //alignItems: "center",\
    borderRadius: 5,
    backgroundColor: "#FBFBFB",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },

  title: {
    fontSize: 33,
    color: "#232323",
    fontWeight: 700,
  },

  title2: {
    fontSize: 14,
    color: "#232323",
    fontWeight: 700,
  },

  title3: {
    fontSize: 13,
    color: "#232323",
    fontWeight: 700,
  },

  buttonRoot: {
    width: 158,
    fontWeight: 500,

    fontSize: 17,
    borderRadius: 34,
  },

  wrapper: {
    position: "relative",
  },

  buttonProgress: {
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -10,
    marginLeft: -12,
  },
}));

export default function Register() {
  const classes = useStyles();
  const [isSuccess, setIsSuccess] = useState([]);
  const [loading, setLoading] = React.useState(false);
  const [compenies, setCompenies] = React.useState([]);
  const Validate = (values) => {
    const errors = {};
    if (!values.firstName) {
      errors.firstName = "Required";
    } else if (!values.email) {
      errors.email = "Required";
    }
    if (!values.password) {
      errors.password = "Required";
    }
    if (!values.companyId) {
      errors.companyId = "Required";
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
      errors.email = "Invalid email address";
    }
    return errors;
  };

  const getCompanies = async () => {
    let result = await GetCompanies();
    setCompenies(result);

    console.log(result);
  };
  useEffect(() => {
    getCompanies();
  }, []);
  const submit = async (values) => {
    setLoading(true);
    let res = await UserRegister({ ...values });

    setIsSuccess(res);
    setLoading(false);
    setTimeout(() => {
      if (res && res.isSuccess) {
        window.location.replace("/login");
      }
    }, 400);
  };

  const initialValue = {
    firstName: "",
    lastName: "none",
    email: "",
    password: "",
    company: "",
  };

  return (
    <Formik
      initialValues={initialValue}
      validate={(values) => Validate(values)}
      onSubmit={(values, { setSubmitting }) => {
        submit(values);
        setTimeout(() => {
          setSubmitting(false);
        }, 400);
      }}
    >
      {({ errors, handleChange, handleSubmit, values }) => (
        <Grid container component="main" className={classes.root}>
          <Grid item xs={false} sm={4} md={7} className={classes.image} />
          <Grid className={classes.paper} item xs={12} sm={8} md={5}>
            <div
              style={{
                marginTop: 40,
                marginBottom: 40,
                marginLeft: 20,
                marginRight: 20,
              }}
            >
              <Box alignItems="center" display="flex">
                <Box mr={5}>
                  <Typography className={classes.title}>Sign Up</Typography>
                </Box>
                {/* <Box>
                  <Typography className={classes.title2}>
                    Financial Analytics
                  </Typography>
                  <Typography className={classes.title2}>
                    made smarter than ever
                  </Typography>
                </Box> */}
              </Box>

              <TextField
                //variant="outlined"
                margin="normal"
                required
                fullWidth
                error={Boolean(errors.firstName)}
                onChange={handleChange}
                helperText={errors.firstName}
                id="firstName"
                label="User Name"
                name="firstName"
                autoFocus
              />
              <TextField
                //variant="outlined"
                margin="normal"
                required
                fullWidth
                id="email"
                error={Boolean(errors.email)}
                onChange={handleChange}
                helperText={errors.email}
                label="Email Address"
                name="email"
                autoComplete="email"
                autoFocus
              />
              <CustomSelect
                values={compenies}
                error={Boolean(errors.company)}
                handleChange={handleChange}
              ></CustomSelect>

              <TextField
                // variant="outlined"
                margin="normal"
                required
                fullWidth
                name="password"
                label="Password"
                error={Boolean(errors.password)}
                onChange={handleChange}
                helperText={errors.password}
                type="password"
                id="password"
                autoComplete="current-password"
              />

              <Grid
                direction="row"
                justify="center"
                alignItems="center"
                container
                spacing={2}
              >
                <Grid item xs>
                  <div className={classes.wrapper}>
                    <Button
                      classes={{ root: classes.buttonRoot }}
                      onClick={() => handleSubmit()}
                      className={classes.submit}
                      fullWidth
                      data-automation="login-button"
                      disabled={loading}
                      variant="contained"
                      color="secondary"
                    >
                      Sign Up Now
                    </Button>
                    {loading && (
                      <CircularProgress
                        size={24}
                        className={classes.buttonProgress}
                      />
                    )}
                  </div>
                  {/* <Button
                 
                    fullWidth
                   
                    variant="contained"
                    color="secondary"
                   
                  >
                  
                  </Button> */}
                </Grid>
                <Grid item xs>
                  <Link href="/login" variant="body2">
                    {"i am already a member"}
                  </Link>
                </Grid>
              </Grid>
            </div>
            <Divider></Divider>

            <Box p={2} alignItems="center" display="flex">
              <Box mr={5}>
                <Typography className={classes.title2}>
                  or connect With -
                </Typography>
              </Box>
              <Box>
                <Button
                  style={{
                    marginRight: 10,
                    borderRadius: 35,
                    width: 110,
                    backgroundColor: "#FCC43F",
                  }}
                  color="secondary"
                  variant="contained"
                >
                  google
                </Button>
                <Button
                  style={{
                    marginRight: 10,
                    borderRadius: 35,
                    width: 110,
                    backgroundColor: "#FCC43F",
                  }}
                  color="secondary"
                  variant="contained"
                >
                  facebook
                </Button>
              </Box>
            </Box>
            {isSuccess && isSuccess.isSuccess && (
              <Alert severity="success">successfuly registerd!</Alert>
            )}

            {isSuccess && isSuccess.isSuccess === false && (
              <Alert severity="error">{isSuccess.message}!</Alert>
            )}
          </Grid>
        </Grid>
      )}
    </Formik>
  );
}
