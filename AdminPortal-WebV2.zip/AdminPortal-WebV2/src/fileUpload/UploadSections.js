import React from "react";
import { Box, Typography, Link } from "@material-ui/core";
import BackupIcon from "@material-ui/icons/Backup";
function UploadSections({ onChangeHandler }) {
  const dragOver = (e) => {
    e.preventDefault();
  };

  const dragEnter = (e) => {
    e.preventDefault();
  };

  const dragLeave = (e) => {
    e.preventDefault();
  };

  const fileDrop = (e) => {
    e.preventDefault();
    const files = e.dataTransfer.files[0];
    console.log(e);
  };
  return (
    <Box
      borderColor="#DDDDDD"
      height={400}
      borderRadius={5}
      width={400}
      border="dotted"
      bgcolor="#FCFCFC"
      className="drop-container"
      onDragOver={dragOver}
      textAlign="center"
      onDragEnter={dragEnter}
      onDragLeave={dragLeave}
      onDrop={fileDrop}
    >
      <BackupIcon
        style={{ fontSize: 94, marginTop: "30%", color: "#E2E2E2" }}
      ></BackupIcon>
      <Box textAlign="center">
        <Typography>Drop files to upload or</Typography>
        <input type="file" name="file" onChange={onChangeHandler} />
      </Box>
    </Box>
  );
}

export default UploadSections;
