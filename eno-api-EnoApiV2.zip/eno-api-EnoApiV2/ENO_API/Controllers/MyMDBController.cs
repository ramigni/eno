﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

using CsvHelper;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using ENO_API.Data;
using ENO_API.Models;
using ENO_API.Services;
using Microsoft.AspNet.OData;
using Microsoft.AspNet.OData.Routing;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace ENO_API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
   
    public abstract class MyMDBController<TEntity, TRepository> : ControllerBase
         where TEntity : class, IEntity
         where TRepository : IRepository<TEntity>
    {
        private readonly TRepository repository;
        private readonly IBlobService _blobService;
        private readonly IConfiguration _config;
      

        public MyMDBController(TRepository repository, IConfiguration config, IBlobService blobService)
        {
            this.repository = repository;
            this._blobService = blobService;
            this._config = config;
            System.Security.Claims.ClaimsPrincipal currentUser = this.User;
        }

    
    }


}