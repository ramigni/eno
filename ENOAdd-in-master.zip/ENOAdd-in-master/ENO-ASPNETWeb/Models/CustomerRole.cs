﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ENOASPNET.Models
{
    public class CustomerRole
    {
        public int Id { get; set; }
        public String Role { get; set; }
    }
}