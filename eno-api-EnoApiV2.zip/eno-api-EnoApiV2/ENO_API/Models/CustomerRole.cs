﻿using ENO_API.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Models
{
    public class CustomerRole:IEntity
    {
        public int Id { get; set; }
        public String Role { get; set; }

       
    }
}
