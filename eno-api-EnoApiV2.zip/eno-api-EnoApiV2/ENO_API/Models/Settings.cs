﻿using ENO_API.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Models
{
    public class Settings: IEntity
    {
        public int Id { get; set; }
        public int CompanyId { get; set; }
        public int CustomerId { get; set; }
        public string FileName { get; set; }
        public string FileSettings { get; set; }
        public string SettingName { get; set; }

        public Customer Customer { get; set; }

        public Company Company { get; set; }
    }
}
