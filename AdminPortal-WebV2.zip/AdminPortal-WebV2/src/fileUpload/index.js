import React, { useEffect } from "react";
import { Grid } from "@material-ui/core";
import TabSection from "./TabSection";
import { makeStyles } from "@material-ui/core/styles";
import UploadSections from "./UploadSections";
import { Box } from "@material-ui/core";
import { GetInitialData } from "./../service/AccountService";
import Typography from "@material-ui/core/Typography";

const useStyles = makeStyles((theme) => ({
  upload: {
    // height: "100vh",
  },
}));

function FileUpload() {
  const [file, setFile] = React.useState("");
  const [curnetUser, setCurnetUser] = React.useState({});

  const onChangeHandler = (event) => {
    setFile(event.target.files[0]);
  };

  useEffect(() => {
    let res = GetInitialData();
    setCurnetUser(res);
  }, []);
  return (
    <>
      {curnetUser &&
      curnetUser.customer &&
      curnetUser.customer.isActive === true ? (
        <Grid container>
          <Grid item xs={12} md={5} sm={5}>
            <UploadSections onChangeHandler={onChangeHandler}></UploadSections>
          </Grid>

          <Grid item xs={12} md={7} sm={7}>
            <TabSection file={file}></TabSection>
          </Grid>
        </Grid>
      ) : !curnetUser ? (
        <Box textAlign="center">
          <Typography style={{ color: "red" }}>
            Sign in to access this page
          </Typography>
        </Box>
      ) : (
        ""
      )}
    </>
  );
}

export default FileUpload;
