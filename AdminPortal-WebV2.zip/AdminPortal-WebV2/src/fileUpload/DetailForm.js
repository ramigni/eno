import React from "react";
import { Grid, Typography, Button } from "@material-ui/core";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
//import FormData from "form-data";
import axios from "axios";
import Alert from "@material-ui/lab/Alert";
import { UploadBinaryFile } from "./../service/AccountService";
import Box from "@material-ui/core/Box";
import Loading from "../components/Loading";
import { makeStyles } from "@material-ui/core/styles";
import CircularProgress from "@material-ui/core/CircularProgress";
const useStyles = makeStyles((theme) => ({
  wrapper: {
    position: "relative",
  },

  buttonProgress: {
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -10,
    marginLeft: -12,
  },
}));

function DetailForm({ file }) {
  const [age, setAge] = React.useState("");
  const [isSuccess, setIsSuccess] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const classes = useStyles();
  const handleChange = (event) => {
    setAge(event.target.value);
  };

  const handleSubmit = async () => {
    setLoading(true);
    let res = await UploadBinaryFile(file);
    setIsSuccess(true);
    setLoading(false);

    setTimeout(() => {
      setIsSuccess(false);
    }, 3000);
  };

  return (
    <Box>
      <Grid spacing={4} container>
        <Grid item xs={12}>
          <FormControl size="small" fullWidth variant="outlined">
            <InputLabel id="demo-simple-select-outlined-label">
              Notify by email
            </InputLabel>
            <Select
              labelId="demo-simple-select-outlined-label"
              id="demo-simple-select-outlined"
              value={age}
              onChange={handleChange}
              label="Notify by email"
            >
              <MenuItem value="">
                <em>Nobody</em>
              </MenuItem>
              <MenuItem value={10}>Ten</MenuItem>
              <MenuItem value={20}>Twenty</MenuItem>
              <MenuItem value={30}>Thirty</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12}>
          <FormControl size="small" fullWidth variant="outlined">
            <InputLabel id="demo-simple-select-outlined-label">
              Category
            </InputLabel>
            <Select
              fullWidth
              labelId="demo-simple-select-outlined-label"
              id="demo-simple-select-outlined"
              value={age}
              onChange={handleChange}
              label="Category"
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              <MenuItem value={10}>Category A</MenuItem>
              <MenuItem value={20}>Category B</MenuItem>
              <MenuItem value={30}>Category B</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        {/* <Grid item xs={6}>
          <FormControl size="small" fullWidth variant="outlined">
            <InputLabel id="demo-simple-select-outlined-label">
              Privacy
            </InputLabel>
            <Select
              fullWidth
              labelId="demo-simple-select-outlined-label"
              id="demo-simple-select-outlined"
              value={age}
              onChange={handleChange}
              label="Privacy"
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              <MenuItem value={10}>Ten</MenuItem>
              <MenuItem value={20}>Twenty</MenuItem>
              <MenuItem value={30}>Thirty</MenuItem>
            </Select>
          </FormControl>
        </Grid> */}

        <Grid item xs={12}>
          <Typography>Nobody will be notified of this file upload</Typography>
          <FormControlLabel
            control={<Checkbox value="remember" color="primary" />}
            label="Send me a copy"
          />
        </Grid>

        <Grid item xs={12}>
          <div className={classes.wrapper}>
            <Button
              onClick={handleSubmit}
              style={{ backgroundColor: "#0BB5D9", color: "#ffff" }}
              variant="contained"
            >
              Upload Files
            </Button>
            {loading && (
              <CircularProgress size={24} className={classes.buttonProgress} />
            )}
          </div>
          {/* <Button
            onClick={handleSubmit}
            style={{ backgroundColor: "#0BB5D9", color: "#ffff" }}
            variant="contained"
          >
            Upload Files
          </Button> */}
        </Grid>

        {isSuccess && (
          <Alert severity="success">file uploaded successfuly!</Alert>
        )}
      </Grid>
    </Box>
  );
}

export default DetailForm;
