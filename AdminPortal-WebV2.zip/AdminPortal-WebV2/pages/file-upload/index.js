import FileUpload from "./../../src/fileUpload/index";
export default FileUpload;
