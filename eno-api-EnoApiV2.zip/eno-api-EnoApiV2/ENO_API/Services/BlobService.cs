﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Azure.Storage.Blobs;

using ENO_API.ExtenSions;
using ENO_API.Models;

namespace ENO_API.Services
{
    public class BlobService : IBlobService
    {
        private readonly BlobServiceClient _blobServiceClient;

        public BlobService(BlobServiceClient blobServiceClient)
        {
            this._blobServiceClient = blobServiceClient;
        }
        public Task DeleteBlobAsync(string filePath, string fileName)
        {
            throw new NotImplementedException();
        }

        public async Task<BlobInfo> GetBlobAsync(string name)
        {
            var containerClient = _blobServiceClient.GetBlobContainerClient("excel");
            var blobClient = containerClient.GetBlobClient(name);
            var blobDownloadInfo =   await blobClient.DownloadAsync();
            return new BlobInfo(blobDownloadInfo.Value.Content, blobDownloadInfo.Value.ContentType);
        }
       
        public  List<string> ListBlobAsync()
        {
            var containerClient = _blobServiceClient.GetBlobContainerClient("excel");
            var items = new List<string>();
            // var blobs = containerClient.GetBlobsAsync();
            foreach ( var blobItem in  containerClient.GetBlobs())
            {
                 items.Add(blobItem.Name);
            }
        
            return items;
        }

        public async Task UploadBinaryFileBlobAsync(Stream file,string fileName)
        {
            var containerClient = _blobServiceClient.GetBlobContainerClient("excel");
            var blocClient = containerClient.GetBlobClient(fileName);
            await blocClient.UploadAsync(file);
        }

     

        public Task UploadContentBlobAsync(string filePath, string fileName)
        {
            throw new NotImplementedException();
        }

        public async Task UploadFileBlobAsync(string filePath, string fileName)
        {
            var containerClient = _blobServiceClient.GetBlobContainerClient("excel");
            var blocClient = containerClient.GetBlobClient(fileName);
            await blocClient.UploadAsync(filePath,new Azure.Storage.Blobs.Models.BlobHttpHeaders { ContentType = filePath.GetContentType() });
          
        }




      
    }
}
