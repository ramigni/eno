﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Models
{
    public class Test
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
