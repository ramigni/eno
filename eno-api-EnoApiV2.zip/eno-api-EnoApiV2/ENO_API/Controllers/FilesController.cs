﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using CsvHelper;
using ENO_API.Data.EFCore;
using ENO_API.Models;
using ENO_API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace ENO_API.Controllers
{ 
    [EnableCors]
    [Route("api/[controller]")]
    [ApiController]
    public class FilesController : MyMDBController<Customer, EfCoreUserRepository>
    {

    private readonly EfCoreUserRepository repository;
    private readonly IBlobService _blobService;
    public FilesController(EfCoreUserRepository repository,  IBlobService blobService, IConfiguration config) : base(repository, config, blobService)
     {
        this.repository = repository;
        this._blobService = blobService;
           
     }


    [EnableCors("CorsPolicy")]
    [Authorize]
    [HttpGet("getAllFiles")]
    public List<string> GetAllFiles()
    {
        var res = _blobService.ListBlobAsync();
        return res;
    }

        [EnableCors("CorsPolicy")]
        [Authorize]
        [HttpPost("addFileData")]
        public async Task<ActionResult<Attachments>> AddFileData(Attachments file)
        {

            await repository.AddFiles(file);
            return Ok(new Response
            {
                fileName = file.Name,
                message = "file successfuly added",
                isSuccess = true
            }); ;

        }


        [EnableCors("CorsPolicy")]
        [Authorize]
        [HttpGet("getFileAsObject")]
        public async Task<List<object>> GetFileAsObject(string name)
        {
            //var records = new object();
            var cultureInfo = new CultureInfo("en");
            var res = await _blobService.GetBlobAsync(name);

            var sReader = new StreamReader(res.Content);
            var csv = new CsvReader(sReader, cultureInfo);

            csv.Read();
            csv.ReadHeader();

            var csvRecords = csv.GetRecords<object>().ToList();

            return csvRecords;
        }


        [EnableCors("CorsPolicy")]
        [Authorize]
        [HttpPost("uploadFile")]
        public async Task<ActionResult> UploadFile(List<IFormFile> files)
        {
            var fileName = "";
            try
            {
                foreach (var file in files)
                {
                    fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    var stream = file.OpenReadStream();
                    await _blobService.UploadBinaryFileBlobAsync(stream, fileName);

                }

                return Ok(new Response
                {
                    fileName = fileName,
                    message = "file settings uploaded successfuly",
                    isSuccess = true,
                });
            }
            catch (Exception e)
            {

            }

            return NotFound();

        }

        [EnableCors("CorsPolicy")]
        [HttpGet]
        [Route("getExcelFile/{name}")]
        public async Task<ActionResult<Stream>> GetExcelFile(string name)
        {
            var res = await _blobService.GetBlobAsync(name);
            return res.Content;
        }

    }
}