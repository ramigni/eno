import { createMuiTheme } from "@material-ui/core/styles";

// Create a theme instance.
const theme = createMuiTheme({
  palette: {
    background: {
      default: "#FFFFFF",
    },

    primary: {
      // light: will be calculated from palette.primary.main,
      main: "#0271E5",
      // dark: will be calculated from palette.primary.main,
      // contrastText: will be calculated to contrast with palette.primary.main
    },

    secondary: {
      light: "#D8EBFC",
      main: "#F1364D",
      // dark: will be calculated from palette.secondary.main,
      contrastText: "#F9FAFC",
    },

    // Used by `getContrastText()` to maximize the contrast between
    // the background and the text.
    contrastThreshold: 3,
    // Used by the functions below to shift a color's luminance by approximately
    // two indexes within its tonal palette.
    // E.g., shift from Red 500 to Red 300 or Red 700.
    tonalOffset: 0.2,
  },

  typography: {
    subtitle1: {
      fontSize: 12,
      textTransform: "capitalize",
    },
    button: {
      fontSize: 15,
      fontWeight: 400,
      color: "#F3F3F3",
    },
    body1: {
      fontSize: 18,
      fontWeight: 400,
    },

    h6: {
      fontSize: 6,
      fontWeight: 500,
    },
    h5: {
      fontSize: 8,
      fontWeight: 400,
    },
    h4: {
      fontSize: 10,
      fontWeight: 400,
    },
    h3: {
      fontSize: 16,
      fontWeight: 400,
    },
    h2: {
      fontSize: 20,
      opacity: 1,
      fontWeight: 600,
    },

    h1: {
      fontSize: 24,
      color: "#FFFFFF",
      opacity: 1,
      fontWeight: 400,
    },

    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
  },

  overrides: {
    MuiButton: {
      root: {
        "&:hover": {
          textDecoration: "none",
          backgroundColor: "#E82D59",
          color: "white",
          // Reset on touch devices, it doesn't add specificity
          "@media (hover: none)": {
            backgroundColor: "#35C37D",
          },
        },
      },
    },
  },
});

export default theme;
