import Register from "./../../src/account/Register";
export default Register;
