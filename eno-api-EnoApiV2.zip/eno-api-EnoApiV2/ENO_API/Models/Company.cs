﻿using ENO_API.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Models
{
    public class Company:IEntity
    {
        public int Id { get; set; }
        public string CompanyName { get; set; }

        public int CategoryId { get; set; }
        public List<Category> Category { get; set; }
    }
}
