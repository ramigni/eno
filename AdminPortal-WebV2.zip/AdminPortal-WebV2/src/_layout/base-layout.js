import { Container, makeStyles, ThemeProvider } from "@material-ui/core";
import CssBaseline from "@material-ui/core/CssBaseline";

import React from "react";
import theme from "./_theme";
import HeaderBar from "./../headerBar/index";
import { UserContexEl } from "../UserContext";
import { useRouter } from "next/router";
import { GetInitialData } from "./../service/AccountService";
import MyAccount from "./../myAccount/index";

const useStyles = makeStyles(() => ({
  container: {
    minHeight: "calc(100vh - 368px - 207px)",

    [theme.breakpoints.down("xs")]: {
      paddingLeft: 0,
      paddingRight: 0,
    },
  },
}));
export default function BaseLayout({ children }) {
  const classes = useStyles();

  const router = useRouter();
  const isSheckout = router.pathname === "/user-list";
  const isHomePage = router.pathname === "/";
  const myAccountPage = router.pathname === "/my-account";
  const myAccount = router.pathname.split("/")[1] === "my-account";
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />

      <Container className={classes.container}>
        <HeaderBar>
          <UserContexEl>
            {myAccount && !myAccountPage ? (
              <MyAccount>{children}</MyAccount>
            ) : (
              <>{children}</>
            )}
          </UserContexEl>
        </HeaderBar>
      </Container>
    </ThemeProvider>
  );
}
