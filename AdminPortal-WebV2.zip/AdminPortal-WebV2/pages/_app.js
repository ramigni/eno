import Head from "next/head";
import App from "next/app";
import BaseLayout from "../src/_layout/base-layout";
import React, { useEffect } from "react";
class MyApp extends App {
  componentDidMount() {
    // Remove the server-side injected CSS.
    const jssStyles = document.querySelector("#jss-server-side");
    if (jssStyles) {
      jssStyles.parentElement.removeChild(jssStyles);
    }
  }

  render() {
    const { Component, pageProps } = this.props;
    return (
      <>
        <style jsx global>
          {`
            html,
            body,
            #__next {
              min-height: 86vh;
            }
          `}
        </style>
        <Head>
          <meta
            name="viewport"
            content="minimum-scale=1, initial-scale=1, width=device-width"
          />
        </Head>
        <BaseLayout>
          <Component {...pageProps} />
        </BaseLayout>
      </>
    );
  }
}
export default MyApp;
