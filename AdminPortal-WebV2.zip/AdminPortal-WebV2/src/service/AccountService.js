import React from "react";
import axios from "axios";
import Router from "next/router";

const getToken = () => {
  if (window !== undefined) {
    var user = window.localStorage.getItem("_ENOCustomer");
    let val = JSON.parse(user);
    return val && val.token;
  }
};

export const GetInitialData = () => {
  if (window !== undefined) {
    var user = window.localStorage.getItem("_ENOCustomer");
    let val = JSON.parse(user);
    return val;
  }
};

export const CleanLocalStorage = () => {
  window.localStorage.clear();
};

export const GetUrl = (page) => {
  return "https://enoweb.azurewebsites.net/api/account" + page;
};

const Fetch = () => {
  const fetch = axios.create({
    //https://enoweb.azurewebsites.net/api/
    baseURL: "https://enoweb.azurewebsites.net/api/",
    baseURL: "https://localhost:5001/api/",
    timeout: 10000,
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + getToken(),
    },
  });

  return fetch;
};

function serverErrorHandler(error) {
  if (error && error.response && error.response.status === 401) {
    CleanLocalStorage();
    Router.push("/login");
  }
  return {
    error: true,
    message: "Authentication Fail",
    ...(error.response && error.response.data),
  };

  // throw (error && error.response && error.response.data) || {
  //   message: 'Error. Please try again.',
  //   details: {
  //     code: error && error.code,
  //   },
  // };
}
export const AddValuesToLocalStorage = (key, value) => {
  window.localStorage.setItem(key, JSON.stringify(value));
};

function Get(url, data) {
  return Fetch()
    .get(data ? `${url}?${qs.stringify(data)}` : `${url}`)
    .then((response) => response.data)
    .catch(serverErrorHandler);
}

function Post(url, data) {
  return Fetch()
    .post(url, data)
    .then((response) => response.data)
    .catch(serverErrorHandler);
}

function Put(url, data) {
  return Fetch()
    .post(url, data)
    .then((response) => response.data)
    .catch(serverErrorHandler);
}

function Delete(url, data) {
  return Fetch()
    .post(url, data)
    .then((response) => response.data)
    .catch(serverErrorHandler);
}

export const GetUsers = () => {
  return Get("account");
};

export const GetFileList = () => {
  return Get("files/getAllFiles");
};

export const Login = (userName, password) => {
  CleanLocalStorage();
  return Get(`account/login?name=${userName}&password=${password}`);
};

export const UserRegister = (data) => {
  CleanLocalStorage();
  return Post("account/register", data);
};

export const AddFileData = (data) => {
  return Post("files/addFileData", data);
};

export const GetCompanies = () => {
  return Get("account/getCompanies");
};

export const ActivateUSerStatus = (user) => {
  return Post("account/activateCustomer", user);
};

export const Me = (userName) => {
  return Get(`account/me?name=${userName}`);
};

export const UploadBinaryFile = (file) => {
  const data = new FormData();
  data.append("Files", file);
  // axios.defaults.headers = {
  //   "Content-Type": "application/json",
  // };
  // axios
  //   .post("https://localhost:5001/api/account/uploadFile", file, {
  //     // receive two    parameter endpoint url ,form data
  //   })
  //   .then((res) => {
  //     // then print response status
  //     console.log(res.statusText);
  //   });

  axios.defaults.headers = {
    "Content-Type": "multipart/form-data",
    Authorization: "Bearer " + getToken(),
  };
  axios
    .post("https://enoweb.azurewebsites.net/api/files/uploadFile", data)
    .then(function (response) {
      setIsSuccess(true);
    })
    .catch(function (error) {
      console.log(error);
    });
};
export const Logout = () => {
  CleanLocalStorage();
  //window.location.replace("/login");
};
