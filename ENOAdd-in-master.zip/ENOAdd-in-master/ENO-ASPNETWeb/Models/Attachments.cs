﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ENOASPNET.Models
{
    public class Attachments 
    {
        public string Name { get; set; }
        public string URL { get; set; }


        public int CustomerId { get; set; }


        public Customer Customer { get; set; }
        public int Id { get; set; }
    }
}