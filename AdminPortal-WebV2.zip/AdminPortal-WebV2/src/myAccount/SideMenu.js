import { Link } from "@material-ui/core";
import MenuItem from "@material-ui/core/MenuItem";
import MenuList from "@material-ui/core/MenuList";
import { makeStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import React from "react";

const useStyles = makeStyles({
  item: {
    backgroundColor: "#778992",
    color: "#FFFFFF",
    fontSize: 14,
    marginBottom: 2,

    "&:hover": {
      color: "#778992",
      opacity: 1,
    },
  },

  itemList: {},
});

export default function SideMenu() {
  const classes = useStyles();

  return (
    <MenuList className={classes.itemList}>
      <MenuItem
        href="/my-account/"
        component={Link}
        style={{ borderRadius: "5px 5px 0px 0px" }}
        className={classes.item}
      >
        <Typography variant="inherit">Account</Typography>
      </MenuItem>
      <MenuItem
        href="/my-account/file-list"
        component={Link}
        className={classes.item}
      >
        <Typography variant="inherit">File List</Typography>
      </MenuItem>
      <MenuItem
        href="/my-account/user-list"
        style={{ borderRadius: "0px 0px 5px 5px" }}
        component={Link}
        className={classes.item}
      >
        <Typography variant="inherit">User List</Typography>
      </MenuItem>
    </MenuList>
  );
}
