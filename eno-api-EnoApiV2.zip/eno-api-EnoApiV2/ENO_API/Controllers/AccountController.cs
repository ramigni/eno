﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ENO_API.Data;
using ENO_API.Data.EFCore;
using ENO_API.Models;
using ENO_API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace ENO_API.Controllers
{
    [EnableCors]
    [Route("api/[controller]")]
    [ApiController]
  
    public class AccountController : MyMDBController<Customer, EfCoreUserRepository>
    {
        private readonly EfCoreUserRepository repository;

        private readonly IAuthService _authService;
        public AccountController(EfCoreUserRepository repository, IAuthService authService, IBlobService blobService, IConfiguration config) : base(repository, config, blobService)
        {
            this.repository = repository;
            _authService = authService;
        }

        [EnableCors("CorsPolicy")]
        [Authorize]
        [HttpGet]
        public async Task<List<Customer>> Get()
        {
            return await repository.GetAllCustomers();
        }


        [EnableCors("CorsPolicy")]
        [Authorize]
        [HttpPost("activateCustomer")]
        public async Task<ActionResult<Customer>> ActivateUser(Customer customer)
        {
            var res = await repository.GetAllCustomers();
            var cust = res.ToList().Where(c => c.Id == customer.Id).FirstOrDefault();

            Customer cus = new Customer();
            cus = cust;
            cus.IsActive = customer.IsActive;
            await repository.UpdateStatus(cus);
            return Ok(new LoginResponse
            {
                Customer = customer,
                Message = "customer activated successfuly",
                IsSuccess = true,
            }); ;

        }


        [EnableCors("CorsPolicy")]
        [HttpGet("login")]
        public async Task<ActionResult> Login(string name, string password)
        {

            var items = new List<Customer>();
            var res = await repository.GetAllCustomers();

            var cust = res.ToList().Exists(x => x.Email == name.Trim() && x.Password == password.Trim());

            IActionResult response = Unauthorized();
            if (cust)
            {
                var usr = res.ToList().Where(x => x.Email == name.Trim() && x.Password == password.Trim()).FirstOrDefault();
                usr.Password = "";
                var tokenStr = _authService.GenerateJSONWebToken(res.FirstOrDefault());
                response = Ok(new { token = tokenStr });


                if (usr.IsActive == false)
                {
                    return Ok(new LoginResponse
                    {
                        Customer = null,
                        Message = "user not activated",
                        IsSuccess = false,
                        Token = "",
                    });
                }


                return Ok(new LoginResponse
                {
                    Customer = usr,
                    Message = "Loged successfuly",
                    IsSuccess = true,
                    Token = tokenStr,
                    IsAdminAccess = usr.CustomerRoleId == 2,
                }); ;
            }
            else
            {
                return Ok(new LoginResponse
                {
                    Customer = null,
                    Message = "user credentials incorect",
                    IsSuccess = false,
                    Token = "",
                    IsAdminAccess = false
                }); ;
            }
        }


        [EnableCors("CorsPolicy")]
        [Authorize]
        [HttpGet("me")]
        public async Task<ActionResult> Me(string name)
        {
            if (name == null)
            {
                return null;
            }
            var res = await repository.GetAllCustomers();
            var usr = res.ToList().Where(x => x.Email == name.Trim()).FirstOrDefault();
            var tokenStr = _authService.GenerateJSONWebToken(res.FirstOrDefault());
            usr.Password = "";
            return Ok(new LoginResponse
            {
                Customer = usr,
                Message = "Logged in successfully ",
                IsSuccess = true,
                Token = tokenStr,
                IsAdminAccess = usr.CustomerRoleId == 2,
            }); ;
        }


        [EnableCors("CorsPolicy")]
        [HttpPost("register")]
        public async Task<ActionResult<Customer>> Register(Customer user)
        {

            var res = await repository.GetAllCustomers();
            var cust = res.ToList().Exists(x => x.Email.Trim() == user.Email.Trim());

            if (cust)
            {
                return Ok(new LoginResponse
                {
                    Customer = null,
                    Message = "user allready exists",
                    IsSuccess = false,
                    Token = "",
                });
            }


            await repository.AddCustomer(user);
            return Ok(new LoginResponse
            {
                Customer = null,
                Message = "user registered successfuly",
                IsSuccess = true,
                Token = "",
            });

        }


        [EnableCors("CorsPolicy")]
        [HttpGet("getCompanies")]
        public async Task<ActionResult<Company>> GetCompanies()
        {
            var res = await repository.GetAllCompanies();
            return Ok(res);
        }




    }
}