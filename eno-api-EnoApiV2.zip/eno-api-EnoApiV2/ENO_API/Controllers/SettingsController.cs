﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ENO_API.Data.EFCore;
using ENO_API.Models;
using ENO_API.Services;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace ENO_API.Controllers
{
    public class SettingsController : MyMDBController<Customer, EfCoreUserRepository>
    {

        private readonly EfCoreUserRepository repository;
        private readonly IBlobService _blobService;
        public SettingsController(EfCoreUserRepository repository, IBlobService blobService, IConfiguration config) : base(repository, config, blobService)
        {
            this.repository = repository;
            this._blobService = blobService;

        }

        [EnableCors("CorsPolicy")]
        [HttpGet("getAllSettings")]
        public async Task<ActionResult<Company>> GetAllSettings()
        {
            var res = await repository.GetAllSettings();
            return Ok(res);
        }

        [EnableCors("CorsPolicy")]
        [HttpGet("updateSettings")]
        public async Task<ActionResult<Settings>> UpdateSettings(Settings setting)
        {

            var setingInfo = await repository.GetSettingBySettingName(setting.SettingName);

            Settings settings = new Settings
            {
                CompanyId = setingInfo.FirstOrDefault().CompanyId,
                CustomerId = setingInfo.FirstOrDefault().CustomerId,
                FileSettings = setting.FileSettings,
                SettingName = setting.SettingName,
                FileName = setingInfo.FirstOrDefault().FileName,
            };

            var res = await repository.UpdateSettingByName(setting);
            return Ok(res);
        }

        [EnableCors("CorsPolicy")]
        [HttpGet("getSettingsByFileName")]
        public async Task<ActionResult<Company>> GetSettingsByFileName(string fileName)
        {
            var res = await repository.GetSettingByFileName(fileName);
            return Ok(res);
        }

        [EnableCors("CorsPolicy")]
        [HttpGet("getSettingsBySettingName")]
        public async Task<ActionResult<Company>> GetSettingsBySettingName(string settingName)
        {
            var res = await repository.GetSettingBySettingName(settingName);
            return Ok(res);
        }


        [EnableCors("CorsPolicy")]
        //  [Authorize]
        [HttpPost("addSettings")]
        public async Task<ActionResult<Settings>> AddSettings(string settings, string email, string fileName, string settingName)
        {

            var res = await repository.GetAllCustomers();
            var cust = res.ToList().Where(x => x.Email == email.Trim()).FirstOrDefault();

            if (cust == null)
            {
                return Ok(new SettingsResponse
                {
                    FileName = "",
                    message = "Please login to the system",
                    isSuccess = false
                });
            }
            Settings stn = new Settings
            {
                FileSettings = settings,
                FileName = fileName,
                CompanyId = cust.Company.Id,
                CustomerId = cust.Id,
                SettingName = settingName,
            };

            await repository.AddSettings(stn);
            return Ok(new SettingsResponse
            {
                FileName = stn.FileName,
                message = "file successfuly added",
                isSuccess = true
            }); ;

        }
    }
}