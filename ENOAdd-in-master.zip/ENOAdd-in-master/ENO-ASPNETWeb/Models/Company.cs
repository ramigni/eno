﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ENOASPNET.Models
{
    public class Company
    {
        public int Id { get; set; }
        public string CompanyName { get; set; }

        public int CategoryId { get; set; }
    }
}