﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;


namespace ENOASPNET.Helpers
{
    public class RESTHelper
    {
        /// <summary>
        /// Get the base64 encoded string from web config
        /// </summary>
        //private static string ApiKey = ConfigurationManager.AppSettings[Constant.WebConfigKeys.APIKEY];
        //private static string ApiKeyCaption = ConfigurationManager.AppSettings[Constant.WebConfigKeys.APIKEYCAPTION];

        /// <summary>
        /// Get the decoded vale of api key
        /// </summary>
        /// <returns> decoded value</returns>
        private static string GetDecodedAPIKey()
        {
            byte[] data = System.Convert.FromBase64String("");
            string decodedAPIKey  = System.Text.ASCIIEncoding.ASCII.GetString(data);
            return decodedAPIKey;
        }

        internal static async Task<T> GetItem<T>(string itemsUrl, string accessToken)
        {
            dynamic jsonData = await PostRequestWithAPIKey(itemsUrl, accessToken);

            // Convert to .NET class and populate the properties of the model objects,
            // and then populate the IEnumerable object and return it.
            //  JArray jsonArray = jsonData;
            return JsonConvert.DeserializeObject<T>(jsonData.ToString());
        }
        /// <summary>
        /// Sends a request to the specified OData URL with the specified access token.
        /// </summary>
        /// <param name="itemsUrl">The OData endpoint URL.</param>
        /// <param name="accessToken">The access token for the endpoint resource.</param>
        /// <returns></returns>
        internal static async Task<dynamic> PostRequestWithAPIKey(string itemsUrl, string data)
        {
            dynamic jsonData = null;
            string apiKey = GetDecodedAPIKey();


            using (var client = new HttpClient())
            {
                try
                {
                    var contentData = new StringContent(data, Encoding.UTF8, "application/json");
                    //client.DefaultRequestHeaders.Add(ApiKeyCaption, GetDecodedAPIKey());
                    var responseMessage = await client.PostAsync(itemsUrl, contentData);

                    if (responseMessage.IsSuccessStatusCode)
                    {
                        HttpContent content = responseMessage.Content;
                        string responseContent = await content.ReadAsStringAsync();
                        //jsonData = JsonConvert.DeserializeObject(responseContent);
                       jsonData =responseContent;

                    }
                    else
                    {
                        jsonData = responseMessage;
                    }
                }
                catch (Exception e){
                    Console.Write(e.InnerException.Message);
                }
            }
            return jsonData;
        }


        internal static async Task<dynamic> GetRequest(string itemsUrl)
        {
            dynamic jsonData = null;
            string apiKey = GetDecodedAPIKey();


            using (var client = new HttpClient())
            {
                try
                {
                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
                   // client.DefaultRequestHeaders.Add("Content-Type", "application/json");
                    var responseMessage = await client.GetAsync(itemsUrl);

                    if (responseMessage.IsSuccessStatusCode)
                    {
                        HttpContent content = responseMessage.Content;
                        string responseContent = await content.ReadAsStringAsync();
                        //jsonData = JsonConvert.DeserializeObject(responseContent);
                        jsonData = responseContent;

                    }
                    else
                    {
                        jsonData = responseMessage;
                    }
                }
                catch (Exception e)
                {
                    Console.Write(e.InnerException.Message);
                }
            }
            return jsonData;
        }

        internal static async Task<dynamic> GetRequestWithAPIKey(string itemsUrl,string tocken)
        {
            dynamic jsonData = null;
            string apiKey = GetDecodedAPIKey();


            using (var client = new HttpClient())
            {
                try
                {
                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer",tocken);
                    // client.DefaultRequestHeaders.Add("Authorization", "Bearer"+ tocken);
                    var responseMessage = await client.GetAsync(itemsUrl);

                    if (responseMessage.IsSuccessStatusCode)
                    {
                        HttpContent content = responseMessage.Content;
                        string responseContent = await content.ReadAsStringAsync();
                        //jsonData = JsonConvert.DeserializeObject(responseContent);
                        jsonData = responseContent;

                    }
                    else
                    {
                        jsonData = responseMessage;
                    }
                }
                catch (Exception e)
                {
                    Console.Write(e.InnerException.Message);
                }
            }
            return jsonData;
        }

    }
}