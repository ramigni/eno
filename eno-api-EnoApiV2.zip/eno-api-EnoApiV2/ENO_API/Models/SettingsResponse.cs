﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Models
{
    public class SettingsResponse
    {
        public string Settings { get; set; }
        public string FileName { get; set; }
        public string message { get; set; }

        public bool isSuccess { get; set; }
    }
}
