import React, { useState } from "react";
import Avatar from "@material-ui/core/Avatar";
import Button from "@material-ui/core/Button";

import TextField from "@material-ui/core/TextField";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Link from "@material-ui/core/Link";
import Paper from "@material-ui/core/Paper";
import Box from "@material-ui/core/Box";
import Grid from "@material-ui/core/Grid";
import LockOutlinedIcon from "@material-ui/icons/LockOutlined";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import axios from "axios";
import { Formik } from "formik";
import Alert from "@material-ui/lab/Alert";
import { useUsers } from "./../UserContext";
import { useRouter } from "next/router";
import {
  Login,
  AddValuesToLocalStorage,
  CleanLocalStorage,
} from "./../service/AccountService";
import CircularProgress from "@material-ui/core/CircularProgress";
const useStyles = makeStyles((theme) => ({
  root: {
    // height: "100vh",
  },
  image: {
    backgroundImage: "url(/assets/images/ENO_Logo.png)",
    backgroundRepeat: "no-repeat",

    backgroundPosition: "center",
  },
  paper: {
    margin: theme.spacing(8, 4),
    display: "flex",
    flexDirection: "column",
    //alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(1, 0, 1),
  },

  title: {
    fontSize: 22,
    color: "#232323",
    fontWeight: 700,
  },

  title2: {
    fontSize: 14,
    color: "#232323",
    fontWeight: 700,
  },

  title3: {
    fontSize: 13,
    color: "#232323",
    fontWeight: 700,
  },

  linkBlue: {
    color: "#7BA4D4",
    fontSize: 13,
    fontWeight: 500,
  },

  linkBlack: {
    color: "#232323",
    fontSize: 13,
    fontWeight: 500,
    marginRight: 8,
  },

  wrapper: {
    position: "relative",
  },

  buttonProgress: {
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -10,
    marginLeft: -12,
  },
}));

export default function SignInSide() {
  const classes = useStyles();
  const [data, setData] = useState([]);
  const [loading, setLoading] = React.useState(false);
  const router = useRouter();
  const user = useUsers();
  console.log(232322332, user);
  const testAPt = () => {
    axios.get(`http://enoweb.azurewebsites.net/api/account`).then((res) => {
      const persons = res;
      console.log(23, persons);
    });

    // axios
    //   .post("https://localhost:5001/api/account/register", {})
    //   .then(function (response) {
    //     console.log(response);
    //   })
    //   .catch(function (error) {
    //     console.log(error);
    //   });
  };

  const Validate = (values) => {
    const errors = {};
    if (!values.email) {
      errors.email = "Required";
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
      errors.email = "Invalid email address";
    }
    if (!values.password) {
      errors.password = "Required";
    }
    return errors;
  };

  const submit = async (values) => {
    setLoading(true);
    CleanLocalStorage();
    const res = await Login(values.email, values.password);
    setData(res);

    AddValuesToLocalStorage("_ENOCustomer", res);
    user.setUser(res);
    setLoading(false);
    setTimeout(() => {
      if (res && res.isSuccess) {
        window.location.replace("/");
      }
    }, 1000);
  };
  const initialValue = {
    name: "",
    password: "",
  };

  return (
    <Formik
      initialValues={initialValue}
      validate={(values) => Validate(values)}
      onSubmit={(values, { setSubmitting }) => {
        submit(values);
        setTimeout(() => {
          setSubmitting(false);
        }, 400);
      }}
    >
      {({ errors, handleChange, handleSubmit, values }) => (
        <form className={classes.form} onSubmit={handleSubmit}>
          <Grid container component="main" className={classes.root}>
            <Grid item xs={false} sm={4} md={7} className={classes.image} />

            <Grid item xs={12} sm={8} md={5}>
              <div className={classes.paper}>
                <Typography className={classes.title}>Welcome</Typography>
                <Typography className={classes.title2}>
                  Sign in to get started
                </Typography>

                <TextField
                  variant="outlined"
                  margin="normal"
                  required
                  size="medium"
                  fullWidth
                  error={Boolean(errors.email)}
                  onChange={handleChange}
                  helperText={errors.email}
                  id="email"
                  label="Email Address"
                  name="email"
                  autoComplete="email"
                  autoFocus
                />
                <TextField
                  size="medium"
                  variant="outlined"
                  margin="normal"
                  required
                  fullWidth
                  error={Boolean(errors.password)}
                  onChange={handleChange}
                  helperText={errors.password}
                  name="password"
                  label="Password"
                  type="password"
                  id="password"
                  autoComplete="current-password"
                />
                {/* <FormControlLabel
              control={<Checkbox value="remember" color="primary" />}
              label="Remember me"
            /> */}
                <Box textAlign="right">
                  <Link
                    className={classes.linkBlue}
                    href="/incomplete"
                    variant="body2"
                  >
                    <Box display="flex" alignItems="center">
                      <img
                        height="20"
                        width="15"
                        src="/assets/images/small_next.JPG"
                        alt=""
                      ></img>
                      {"  "}
                      Forgot password?
                    </Box>
                  </Link>
                </Box>

                <div className={classes.wrapper}>
                  <Button
                    type="submit"
                    className={classes.submit}
                    fullWidth
                    data-automation="login-button"
                    disabled={loading}
                    variant="contained"
                    color="primary"
                  >
                    Login
                  </Button>
                  {loading && (
                    <CircularProgress
                      size={24}
                      className={classes.buttonProgress}
                    />
                  )}
                </div>
                {/* <Button
                fullWidth
                variant="contained"
                color="primary"
                className={classes.submit}
             
              >
                Login
              </Button> */}
                <Box textAlign="center">
                  <Link
                    className={classes.linkBlack}
                    href="/register"
                    variant="body2"
                  >
                    {"Don't have an account? "}

                    <Typography display="inline" className={classes.linkBlue}>
                      Sign Up
                    </Typography>
                  </Link>
                </Box>
                <Box>
                  {data && data.isSuccess && (
                    <Alert severity="success">{data && data.message}</Alert>
                  )}
                  {data && data.isSuccess === false && (
                    <Alert severity="error">{data && data.message}</Alert>
                  )}
                </Box>
                <Box mt={5}>
                  <Typography className={classes.title}>
                    Download Eno Excel plugin
                  </Typography>
                </Box>
                <Box mt={3} textAlign="center">
                  <img
                    src="/assets/images/next.png"
                    alt=""
                    height="40"
                    width="60"
                  ></img>
                </Box>
              </div>
            </Grid>
          </Grid>
        </form>
      )}
    </Formik>
  );
}
