﻿using ENO_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Services
{
    public interface IAuthService
    {
        string GenerateJSONWebToken(Customer customer);

    }
}
