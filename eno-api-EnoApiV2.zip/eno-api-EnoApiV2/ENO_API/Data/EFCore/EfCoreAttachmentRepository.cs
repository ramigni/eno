﻿using ENO_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Data.EFCore
{
   
        public class EfCoreAttachmentRepository : EfCoreRepository<Attachments, MyMDBContext>
        {
            public EfCoreAttachmentRepository(MyMDBContext context) : base(context)
            {

            }
            
        }
    
}
