﻿using ENO_API.Data;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Models
{
    public class Attachments : IEntity
    {
        public string Name{ get; set; }
        public string URL { get; set; }

        [ForeignKey("Customer")]
        public int CustomerId { get; set; }


        public Customer Customer { get; set; }
        public int Id { get; set; }
    }
}
