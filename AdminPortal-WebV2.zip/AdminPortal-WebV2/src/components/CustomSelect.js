import React from "react";
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import Select from "@material-ui/core/Select";
import FormHelperText from "@material-ui/core/FormHelperText";
import MenuItem from "@material-ui/core/MenuItem";

function CustomSelect({ handleChange, values, error = false }) {
  const [company, setCompany] = React.useState("");
  const selectHandleChange = (event) => {
    setCompany(event.target.value);
    handleChange(event);
  };
  return (
    <FormControl margin="normal" size="small" fullWidth>
      <InputLabel id="company">Company</InputLabel>
      <Select
        fullWidth
        labelId="company"
        id="company"
        value={company}
        onChange={selectHandleChange}
        label="Company"
        name="companyId"
      >
        <MenuItem value="">
          <em>Select Company</em>
        </MenuItem>
        {values &&
          values.length &&
          values.map((item) => (
            <MenuItem value={item.id}>{item.companyName}</MenuItem>
          ))}
      </Select>
      {error && (
        <FormHelperText style={{ color: "red" }}>Select Company</FormHelperText>
      )}
    </FormControl>
  );
}

export default CustomSelect;
