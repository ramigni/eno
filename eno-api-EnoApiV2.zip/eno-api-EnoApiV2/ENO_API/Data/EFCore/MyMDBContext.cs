﻿using ENO_API.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Data.EFCore
{
    public class MyMDBContext:DbContext
    {
        public MyMDBContext(DbContextOptions<MyMDBContext> options)
       : base(options)
        {
        }

        public DbSet<Customer> Customer { get; set; }
        public DbSet<Attachments> Attachments { get; set; }

        public DbSet<Company> Company { get; set; }

        public DbSet<Category> Category { get; set; }

        public DbSet<CustomerRole> CustomerRole { get; set; }

        public DbSet<Settings> Settings { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }
        
    }
}
