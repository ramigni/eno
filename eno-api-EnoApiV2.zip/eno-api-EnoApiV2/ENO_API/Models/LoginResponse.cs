﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Models
{
    public class LoginResponse
    {

        public Customer Customer { get; set; }
        public string Message { get; set; }
        public bool IsSuccess { get; set; }
        public string Token { get; set; }
        public bool IsAdminAccess { get; set; }
    }
}
