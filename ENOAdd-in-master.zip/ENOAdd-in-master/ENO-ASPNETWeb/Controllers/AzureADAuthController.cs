﻿// Copyright (c) Microsoft. All rights reserved. Licensed under the MIT license. See full license in the root of the repo.

using Microsoft.Identity.Client;
using Newtonsoft.Json;
using ENOASPNET.Helpers;
using ENOASPNET.Models;
using System;
using System.Data.Entity.Infrastructure;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ENOASPNET.Controllers
{
    public class AzureADAuthController : Controller
    {
        //// The URL that auth should redirect to after a successful login.
        //Uri loginRedirectUri => new Uri(Url.Action(nameof(Login), "AzureADAuth", null, Request.Url.Scheme));

        //// The URL to redirect to after a logout. It is the add-in's home page.
        //Uri logoutRedirectUri => new Uri(Url.Action(nameof(HomeController.Index), "Home", null, Request.Url.Scheme));

        /// <summary>
        /// Logs the user out.
        /// </summary>
        /// <returns>Redirect to logout complete page.</returns>
        /// 
        [System.Web.Mvc.HttpGet]
        public ActionResult Logout()
        {
            var userAuthStateId = Settings.GetUserAuthStateId(ControllerContext.HttpContext);
            Data.DeleteUserSessionToken(userAuthStateId, Settings.AzureADAuthority);
            Response.Cookies.Clear();
            return RedirectToAction("LogoutComplete");
        }

        /// <summary>
        /// Logs the user into Office 365.
        /// </summary>
        /// <param name="authState">The login or logout status of the user.</param>
        /// <returns>A redirect to the Office 365 login page.</returns>
        /// 

        [System.Web.Mvc.HttpGet]
        public async Task<JsonResult> Login(string authState)
        {
            string userName = authState.Split('&')[1];
            string userPwd = authState.Split('&')[2];
            string session = authState.Split('&')[0];

            string name = userName.Split('=')[1];

            string url = @"https://enoweb.azurewebsites.net/api/account/login?{0}&{1}";

            url = string.Format(url, userName, userPwd);
            var result = await RESTHelper.GetRequest(url);

            UserTocken userTocken = JsonConvert.DeserializeObject<UserTocken>(result);
            JsonResult jsreuslt = Json("");
            AuthState authStateObj = JsonConvert.DeserializeObject<AuthState>(session);
           var authResult= await SaveAuthToken(userTocken.Token, name, authStateObj.stateKey);

            if (!String.IsNullOrEmpty(userTocken.Token))
            {
                ViewBag.AuthState = "True";
                 jsreuslt= Json("true", JsonRequestBehavior.AllowGet);
                return jsreuslt;  
            }
            ViewBag.AuthState = "False";
             jsreuslt = Json("false", JsonRequestBehavior.AllowGet);
            return jsreuslt;
        }

        /// <summary>
        /// Authorizes the web application (not the user) to access Microsoft Graph resources by using
        /// the Authorization Code flow of OAuth.
        /// </summary>
        /// <returns>The default view.</returns>
    

            /// <summary>
            /// Stores the access token in a local database. 
            /// </summary>
            /// <param name="authState">Contains user's session ID.</param>
            /// <param name="authResult">The results of the attempt to get the access token.</param>
            /// <returns></returns>
            private static async Task<bool> SaveAuthToken(string tocken, string userName, string sessionID)
        {

            try
            {
                using (var db = new AddInContext())
                {
                    var token = new SessionToken()
                    {
                        Id = sessionID,
                        CreatedOn = DateTime.Now,
                        AccessToken = tocken,
                        Provider = Settings.AzureADAuthority,
                        Username = userName
                    };
                    db.SessionTokens.Add(token);
                    await db.SaveChangesAsync();

                    return true;
                }
            }
            catch (DbUpdateException e)
            {
                return false;
            }
        }

        /// <summary>
        /// Changes the view in the pop-up to tell the user that authentication of the user
        /// and authorization of the web application are finished. 
        /// </summary>
        /// <param name="authState">The login or out status of the user.</param>
        /// <returns>The default view for AuthorizeComplete.</returns>
        public ActionResult AuthorizeComplete(string authState)
        {
            ViewBag.AuthState = authState;
            return View();
        }

        /// <summary>
        /// Changes the view in the pop-up to tell the user that logout is complete. 
        /// </summary>
        /// <returns>The default view for LogoutComplete.</returns>
        public ActionResult LogoutComplete()
        {
            return View();
        }
    }
}
