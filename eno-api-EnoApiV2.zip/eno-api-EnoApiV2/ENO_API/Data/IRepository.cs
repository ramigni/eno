﻿using ENO_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Data
{
    public interface IRepository<T> where T : class, IEntity
    {
        Task<List<T>> GetAll();
        Task<List<Customer>> GetAllCustomers();
        Task<T> Get(int id);
        Task<T> Add(T entity);
        Task<Customer> UpdateStatus(Customer customer);
        Task<Attachments> AddFiles(Attachments file);
        Task<Customer> AddCustomer(Customer customer);
        Task<List<Company>> GetAllCompanies();
        Task<Settings> AddSettings(Settings settings);
        Task<List<Settings>> GetAllSettings();
        Task<List<Settings>> GetSettingByFileName(string fileName);
        Task<List<Settings>> GetSettingBySettingName(string settingName);
        Task<Settings> UpdateSettingByName(Settings setting);

    }
}
