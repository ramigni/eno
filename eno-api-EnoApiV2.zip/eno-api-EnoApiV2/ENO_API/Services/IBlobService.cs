﻿
using ENO_API.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Services
{
    public interface IBlobService 
    {
         Task<BlobInfo> GetBlobAsync(string name);
        List<string> ListBlobAsync();

         Task UploadFileBlobAsync(string filePath,string fileName);

        Task  UploadBinaryFileBlobAsync(Stream file, string fileName);

        Task UploadContentBlobAsync(string filePath, string fileName);

        Task DeleteBlobAsync(string filePath, string fileName);
    }
}
