﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Models
{
    public class BlobInfo
    {
        public BlobInfo(Stream content, string contentType)
        {
            this.ContentType = contentType;
            this.Content = content;
        }
        public Stream Content { get; set; }
        public string ContentType { get; set; }
    
}
}
