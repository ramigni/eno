import Paper from "@material-ui/core/Paper";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import React, { useEffect, useState } from "react";
import {
  GetFileList,
  GetInitialData,
  GetUrl,
} from "./../service/AccountService";
import Loading from "./../components/Loading";
import Box from "@material-ui/core/Box";
import Typography from "@material-ui/core/Typography";
import { Link } from "@material-ui/core";

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
});

export default function FileList() {
  const classes = useStyles();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [curnetUser, setCurnetUser] = React.useState({});
  const getAllFiles = async () => {
    setLoading(true);
    let userData = await GetFileList();
    setUsers(userData);

    setLoading(false);
  };

  useEffect(() => {
    getAllFiles();
    let res = GetInitialData();
    setCurnetUser(res);
  }, []);

  return (
    <>
      {curnetUser &&
      curnetUser.customer &&
      curnetUser.customer.isActive === true ? (
        <Box textAlign="center">
          {loading ? (
            <Loading />
          ) : (
            <TableContainer component={Paper}>
              <Table className={classes.table} aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell>File Name</TableCell>
                    <TableCell align="right">URL</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {users &&
                    users.length > 0 &&
                    users.map((file) => (
                      <TableRow>
                        <TableCell component="th" scope="row">
                          {file}
                        </TableCell>
                        <TableCell align="right">
                          <Link href={GetUrl()}></Link>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Box>
      ) : !curnetUser ? (
        <Box textAlign="center">
          <Typography style={{ color: "red" }}>
            Sign in to access this page
          </Typography>
        </Box>
      ) : (
        ""
      )}
    </>
  );
}
