﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ENO_API.Data.EFCore;
using ENO_API.Models;
using ENO_API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace ENO_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AttachmentController : MyMDBController<Attachments, EfCoreAttachmentRepository>
    {
        public AttachmentController(EfCoreAttachmentRepository repository, IBlobService blobService, IConfiguration config) : base(repository,config, blobService)
        {

        }
    }
}

