import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import { GetUsers } from "../service/AccountService";
import axios from "axios";
import ActivatieUser from "./ActivatieUser";
import Box from "@material-ui/core/Box";
import Loading from "../components/Loading";
import Typography from "@material-ui/core/Typography";
import { GetInitialData } from "./../service/AccountService";
const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
});

export default function UserList() {
  const classes = useStyles();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [curnetUser, setCurnetUser] = React.useState({});

  const getUsers = async () => {
    setLoading(true);
    let users = await GetUsers();
    //console.log(3566667, users);
    setUsers(users);
    setLoading(false);
  };

  useEffect(() => {
    getUsers();
    let res = GetInitialData();
    setCurnetUser(res);
  }, []);

  return (
    <>
      {curnetUser &&
      curnetUser.isAdminAccess === true &&
      curnetUser.customer &&
      curnetUser.customer.isActive === true ? (
        <Box textAlign="center">
          {loading ? (
            <Loading></Loading>
          ) : (
            <TableContainer component={Paper}>
              <Table className={classes.table} aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell>User Name</TableCell>
                    <TableCell align="right">Role</TableCell>
                    <TableCell align="right">Company</TableCell>
                    <TableCell align="right">Status</TableCell>
                    <TableCell align="right">Active</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {users &&
                    users.length > 0 &&
                    users.map((user) => (
                      <TableRow>
                        <TableCell component="th" scope="row">
                          {user.firstName}
                        </TableCell>
                        <TableCell align="right">
                          {user.customerRole.role}
                        </TableCell>
                        <TableCell align="right">
                          {user.company.companyName.toString()}
                        </TableCell>
                        <TableCell align="right">
                          {" "}
                          {user.isActive.toString()}
                        </TableCell>
                        <TableCell align="right">
                          <ActivatieUser
                            status={Boolean(user.isActive)}
                            customer={user}
                            getUsers={getUsers}
                          ></ActivatieUser>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Box>
      ) : !curnetUser ? (
        <Box textAlign="center">
          <Typography style={{ color: "red" }}>
            Sign in to access this page
          </Typography>
        </Box>
      ) : (
        ""
      )}
    </>
  );
}
