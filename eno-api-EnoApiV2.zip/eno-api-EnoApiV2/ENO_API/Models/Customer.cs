﻿using ENO_API.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ENO_API.Models
{
    public class Customer : IEntity
    {
        public Customer()
        {
            CustomerRoleId = 1;
            CompanyId = 1;
        }
        public int Id { get; set; }

        [Required]

        public string FirstName { get; set; }

        public string LastName { get; set; }
    
        public int CustomerRoleId { get; set; }
        [Required]
        public string Email { get; set; }
      
        public bool IsActive { get; set; }
        public string Password { get; set; }

     
        public int CompanyId { get; set; }

      
        public Company Company { get; set; }

       
        public CustomerRole CustomerRole { get; set; }
        
        public List<Attachments> Attachments { get; set; }
    }
}
