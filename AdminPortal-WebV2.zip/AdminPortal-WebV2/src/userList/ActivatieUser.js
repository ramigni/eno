import React from "react";
import Switch from "@material-ui/core/Switch";
import { ActivateUSerStatus } from "./../service/AccountService";
function ActivatieUser({ status = false, customer, getUsers }) {
  const [state, setState] = React.useState(status);

  const handleChange = async (event) => {
    let user = {
      id: customer.id,
      IsActive: !state,
      firstName: customer.firstName,
      email: customer.email,
    };
    setState(!state);
    let result = ActivateUSerStatus(user);
    setTimeout(() => {
      getUsers();
    }, 1000);
  };
  return (
    <Switch
      checked={state}
      onChange={handleChange}
      name="checkedA"
      inputProps={{ "aria-label": "secondary checkbox" }}
    />
  );
}

export default ActivatieUser;
