module.exports = {
  exportTrailingSlash: true,
  exportPathMap: function () {
    return {
      "/": { page: "/" },
      "/login": { page: "/login" },
      "/register": { page: "/register" },
      "/file-upload": { page: "/file-upload" },
      "/incomplete": { page: "/incomplete" },
      "/my-account": { page: "/my-account" },
      "/my-account/file-list": { page: "/my-account/file-list" },
      "/my-account/user-list": { page: "/my-account/user-list" },
    };
  },
};

// xportPathMap: async function (
//   defaultPathMap,
//   { dev, dir, outDir, distDir, buildId }
// ) {
//   return {
//     '/': { page: '/' },

//     '/p/hello-nextjs': { page: '/post', query: { title: 'hello-nextjs' } },
//     '/p/learn-nextjs': { page: '/post', query: { title: 'learn-nextjs' } },
//     '/p/deploy-nextjs': { page: '/post', query: { title: 'deploy-nextjs' } },
//   }
// },
