import Grid from "@material-ui/core/Grid";
import { makeStyles } from "@material-ui/core/styles";
import React from "react";
import { Typography } from "@material-ui/core";
import Box from "@material-ui/core/Box";
import Link from "@material-ui/core/Link";

const useStyles = makeStyles((theme) => ({
  root: {
    // height: "100vh",
  },
  image: {
    backgroundImage: "url(/assets/images/ENO_Logo.png)",
    backgroundRepeat: "no-repeat",
    height: 300,
    backgroundPosition: "center",
  },
}));

export default function Home() {
  const classes = useStyles();

  return (
    <Grid container className={classes.root}>
      <Grid item xs={12} sm={12} md={12} className={classes.image} />
      <Grid item xs={12} sm={12} md={12} component={Box} textAlign="center">
        <Typography>Sign in to get access to your data</Typography>
        <Link href="/login" variant="body2">
          {"i am already a member"}
        </Link>
      </Grid>
    </Grid>
  );
}
