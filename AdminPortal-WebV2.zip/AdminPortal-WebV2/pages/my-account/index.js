import MyAccount from "./../../src/myAccount/index";
export default MyAccount;
